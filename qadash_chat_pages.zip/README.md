# Qadash Chat — Paleo‑Hebrew
Upload this folder to GitHub Pages. Ensure `index.html` is at the root.
Then visit `https://<your-username>.github.io/` to view the live app.